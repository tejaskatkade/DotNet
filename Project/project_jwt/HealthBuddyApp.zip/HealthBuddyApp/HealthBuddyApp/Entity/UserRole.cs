﻿namespace HealthBuddyApp.Entity
{
    public enum UserRole
    {
        ROLE_ADMIN,
        ROLE_DOCTOR,
        ROLE_PATIENT
    }
}