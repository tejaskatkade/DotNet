﻿namespace HealthBuddyApp.Entity
{
    public enum Gender
    {
        MALE,
        FEMALE

    }
}