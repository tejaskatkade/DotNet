﻿namespace HealthBuddyApp.DTO.ReqDto
{
    public class LoginReqDto
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
