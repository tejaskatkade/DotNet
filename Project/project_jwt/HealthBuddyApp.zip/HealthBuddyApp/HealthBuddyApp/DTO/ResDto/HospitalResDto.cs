﻿namespace HealthBuddyApp.DTO.ResDto
{
    public class HospitalResDto
    {
        public long Id { get; set; }
        public String Name {  get; set; }
        public String Location {  get; set; }
        public String Contact {  get; set; }
    }
}
