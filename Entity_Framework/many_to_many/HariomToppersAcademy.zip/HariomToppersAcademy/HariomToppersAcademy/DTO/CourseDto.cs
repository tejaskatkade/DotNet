﻿namespace HariomToppersAcademy.DTO
{
    public class CourseDto
    {
        public string Name { get; set; }
        public double Fees { get; set; }

    }
}
