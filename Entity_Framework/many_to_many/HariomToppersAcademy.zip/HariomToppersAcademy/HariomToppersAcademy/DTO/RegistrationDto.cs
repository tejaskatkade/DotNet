﻿namespace HariomToppersAcademy.DTO
{
    public class RegistrationDto
    {
        public int StudetnId {  get; set; }
        public int CourseId { get; set; }
    }
}
